const $ = selector => document.querySelector(selector);

document.addEventListener("DOMContentLoaded", () => {


    document.querySelectorAll('.btn_buy').forEach(item =>{
        item.addEventListener('click', event => {
            alert("WIP | Functionality Coming Soon");
        })
    })

    document.querySelectorAll('.social-icon').forEach(item =>{
        item.addEventListener('click', event => {
            alert("WIP | Functionality Coming Soon");
        })
    })

});