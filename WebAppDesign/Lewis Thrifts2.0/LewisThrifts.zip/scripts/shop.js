$(function() {

    $("#tabs").accordion({collapsible: true, heightStyle: "content" });
    
});