def main():
    # TODO: Finish this function's implementation
    # - print "Hello, World!" to the console
    pass 
    print("Hello, World!")


if __name__ == '__main__':
    main()
